clear all; close all; clc;
run("Inverter_parameters.m");
open("Inverter_model.slx");