clear all; close all; clc;
run("Diesel_Generator_parameters.m");
open("Diesel_Generator_model.slx");